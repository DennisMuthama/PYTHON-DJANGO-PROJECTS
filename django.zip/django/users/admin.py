from django.contrib import admin
from  .models import profile

admin.site.register(profile)
